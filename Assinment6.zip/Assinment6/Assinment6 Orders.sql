use assinment6;
-- create product table 

create table Orders(
OrderID int primary key,
CustomerName varchar(50),
ProductCategory varchar(50),
Quantity int,
TotalPrice Decimal(10,2),
OrderDate Date);

-- INsert value

Insert into orders(OrderID, CustomerName, ProductCategory, Quantity, TotalPrice, OrderDate)
values 
(1, 'Alice',   'Electronics', 2,  1600.00, '2024-11-01'),
   (2, 'Bob', 	'Furniture',   1,   300.00, '2024-11-02'),
   (3, 'Charlie', 'Electronics', 1,   800.00, '2024-11-03'),
   (4, 'Diana',   'Stationery', 10,	50.00, '2024-11-04'),
   (5, 'Eve', 	'Electronics', 3,  2400.00, '2024-11-05'),
   (6, 'Frank',   'Stationery', 20,   100.00, '2024-11-06');

--  a) Total Quantity by Category: Compute total Quantity sold for each ProductCategory.

select ProductCategory, sum(Quantity) as total_sale_Quantity
from Orders
group by ProductCategory;

  -- b) Categories with High Sales Volume: Find categories where total Quantity > 10.
  select ProductCategory, sum(Quantity) AS Total_Quantity from orders
    where Quantity >10
  group by ProductCategory;

    -- c) Average Order Value by Category: Calculate average TotalPrice per ProductCategory.
    select ProductCategory, avg(TotalPrice) from orders
    group by  ProductCategory;

  -- d) Categories with Low Average Price: Identify categories where average TotalPrice < 1000.
 select ProductCategory from
 (select ProductCategory, avg(TotalPrice)As avgprice from orders
group by  ProductCategory) as T
where avgprice <1000;

 --  e) Classify Orders by Value: Add a column marking each order as 'High Value' if TotalPrice > 1000, else 'Low Value'.

select *, 
case 
when TotalPrice >1000 then 'high value'
else 'Low value'
END AS ValueCategory
from orders;

 
